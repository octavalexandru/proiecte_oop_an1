//
// Created by alexa on 3/7/2024.
//

#ifndef LAB1_COMPLEXTEST_H
#define LAB1_COMPLEXTEST_H

#include "Complex.h"

class ComplexTest {
public:
    void TestGetterAndSetter();
    void TestContructorInit();
    void TestConstructorCopiere();
    void TestOperatorInmultire();
    void TestOperatorImpartire();
};


#endif //LAB1_COMPLEXTEST_H
