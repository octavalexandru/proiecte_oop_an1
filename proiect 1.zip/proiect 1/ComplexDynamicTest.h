//
// Created by alexa on 3/7/2024.
//

#ifndef LAB1_COMPLEXDYNAMICTEST_H
#define LAB1_COMPLEXDYNAMICTEST_H


#include "ComplexDynamic.h"


class ComplexDynamicTest {
public:
    void TestCreareComplexSiAfisareValori();
//    void TestContructorInit();
    void TestConstructorCopiere();
    void TestOperatorAtribuire();

};


#endif //LAB1_COMPLEXDYNAMICTEST_H
