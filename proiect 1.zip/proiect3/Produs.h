//
// Created by octav on 27/05/2024.
//

#ifndef PROIECT3_PRODUS_H
#define PROIECT3_PRODUS_H


class Produs {
public:
    virtual double calc_pret() const = 0;
    virtual ~Produs() = default;

};


#endif //PROIECT3_PRODUS_H
